/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2024_08_act1;

/**
 *
 * @author DIANA LOPEZ
 */
public class Individuo {
    
    private double altura;
    private double peso;

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    
    public double obtenerIMC(){
        
        double imc = this.getPeso() / Math.pow(this.getAltura(), 2);

        return imc;
    }
}
